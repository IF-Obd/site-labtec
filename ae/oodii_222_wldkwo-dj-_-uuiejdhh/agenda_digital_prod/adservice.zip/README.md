WEB SERVICE PHP PARA APLICATIVO AGENDA DIGITAL
MÓDULOS ATENDIDO: ALUNO, PROFESSOR, PEDAGÓGICO E RESPONSÁVEL

==========================================================================
PASTAS
/ =  CONTEM OS ARQUIVOS PARA USO GERAL DO WEBSERVICE
UTIL = PASTA DE ARQUIVOS DE CONFIGURAÇÕES E FINÇÕES PADRÕES
AC_PED = PASTA DE AÇÕES PARA O PERFIL PEDAGÓGICO
AC_PROF = PASTA DE AÇÕES PARA O PERFIL PROFESSOR
AC_RES = PASTA DE AÇÕES PARA O PERFIL RESPONSAVEL
AC_ALU = PASTA DE AÇÕES PARA O PERFIL ALUNO
--------------------------------------------------------------------------------

ARQUIVOS DE TESTES
t.html -  testes de html
teste.php - testes de implementações php