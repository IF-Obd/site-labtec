<?php 


class Alunos_Resp {
   
   var $id_aluno;
   var $nome;
   var $email;
   var $matricula;
   var $curso;
   var $turma;
}