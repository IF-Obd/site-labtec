<?php 


class Curso {
   
   var $id_curso;
   var $nome_curso;
   var $sigla;
}