<?php

class Materia {

    var $id;
    var $nome;  
    var $professor;
    var $nome_curso;
    var $sigla_curso;
    var $numero_turma;
    var $qtd_tarefas;

    
}
