<?php


class Tarefa {

    var $id_atividade;
    var $titulo;
    var $descricao;
    var $pontos;
    var $data;
    var $hora;
    var $dataentrega;
    var $disciplina;
    var $professor;
    var $curso;
    var $turma;

}

