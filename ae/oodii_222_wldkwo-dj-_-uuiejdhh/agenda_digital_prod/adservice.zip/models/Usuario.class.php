<?php 


class Usuario {

    var $id_usuario;
    var $nome;
    var $login;
    var $email;
    var $tipoUsuario_id;
    var $status_cad;
    var $cpf;
}

