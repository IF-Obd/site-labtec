<?php 

$data = "2019-02-03 00:20:21";

	//TRADUZ DATA PARA EXIBIR


	$objeto_data = DateTime::createFromFormat('Y-m-d h:i:s',$data);
	$data = $objeto_data->format('d/m/Y-H:i:s');
	$partes = explode("-", $data);

	$dados['data'] = $partes[0];
	$dados['hora'] = $partes[1];
	var_dump($dados);
 ?>